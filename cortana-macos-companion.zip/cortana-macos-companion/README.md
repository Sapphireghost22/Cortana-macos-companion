# Cortana macOS Companion — Made with \[Chat Gpt Luna\]

> A private, local-first MacBook assistant with a witty tactical voice, native diagnostics, and restrained holographic-inspired UI direction.

**Made with \[Chat Gpt Luna\]**

![macOS](https://img.shields.io/badge/platform-macOS-111827?logo=apple)
![Python](https://img.shields.io/badge/python-3.10%2B-3776AB?logo=python)
![Runtime](https://img.shields.io/badge/runtime-local%20first-2563EB)
![License](https://img.shields.io/badge/license-MIT-16A34A)

## Overview

Cortana macOS Companion is an unofficial, Halo 4-inspired desktop assistant proof of concept for standard Intel and Apple Silicon MacBooks. Its original persona is observant, loyal, empathetic, technically sharp, and dryly funny. The project does not use external sensors, beacons, radar, remote speech services, or a cloned character voice.

This repository provides a command-line monitor and a clean foundation for a future SwiftUI menu-bar interface. Hardware readings stay on the Mac. The only network probe is an optional ping to the Mac's current default gateway. No telemetry or conversation history is uploaded.

> Halo, Cortana, and related names are trademarks of their respective owners. This community project is unofficial and is not affiliated with or endorsed by Microsoft or Halo Studios.

## Features

- **Wi-Fi diagnostics:** Read active SSID and RSSI using CoreWLAN, optionally scan nearby networks, and measure packet loss and latency to the local gateway.
- **Bluetooth awareness:** Scan nearby BLE advertisements through Bleak's macOS CoreBluetooth backend; match user-named devices and optionally read a standard GATT battery characteristic.
- **System self-diagnostics:** Read battery percentage and reported cycle count, public macOS thermal state, approximate CPU use, and approximate RAM use.
- **Cortana-inspired persona engine:** Use rule-based alerts, hysteresis, cooldowns, and recovery lines for low battery, thermal stress, network instability, and known-device signal sightings.
- **Thermal-aware polling:** When the thermal state reaches serious or critical, the monitor pauses optional BLE scans while continuing low-frequency system checks.
- **Local voice output:** Use the built-in macOS say command. Voice output is off by default and can be enabled in settings or with --speak.
- **Privacy-minded defaults:** No cloud LLM, remote STT/TTS, radio toggles, or persisted Bluetooth identifiers.

The current scaffold accepts CLI/configuration input and speaks locally. Microphone speech recognition, the animated SwiftUI panel, Spotlight actions, and a local LLM adapter are extension points rather than shipped features.

## Architecture

~~~text
SwiftUI menu-bar UI (next step)
            │ local typed snapshots and persona events
            ▼
main.py ── hardware_bridge.py ── CoreWLAN / CoreBluetooth / macOS tools
   │                 │
   └──── persona_engine.py       └── local gateway ping
            │
            └── macOS say (optional, local)
~~~

The Swift helper exposes the public CoreWLAN and Foundation thermal APIs. Python handles orchestration, BLE scans, parsing system reports, threshold policy, and optional speech. The assistant reports thermal state, not an invented temperature reading.

## Requirements

- macOS 10.15 or later.
- Python 3.10 or later.
- Swift compiler and CoreWLAN SDK, normally supplied by Xcode Command Line Tools.
- Bluetooth permission for the app/runtime that launches Python. Packaged apps must include NSBluetoothAlwaysUsageDescription in their Info.plist.

BLE peripherals must be advertising to appear. A paired phone or AirPods may not advertise while connected, asleep, or using private identifiers. RSSI is an inconsistent radio-strength cue, not a reliable distance measurement. Accessory battery values appear only when macOS reports them or when a peripheral exposes the standard GATT Battery Service.

## Installation

Clone the repository and create an isolated Python environment:

~~~sh
git clone https://github.com/YOUR_USERNAME/cortana-macos-companion.git
cd cortana-macos-companion
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp config.example.json settings.json
~~~

If Swift is not available, install Apple's command-line developer tools:

~~~sh
xcode-select --install
~~~

The first run compiles the small Swift bridge into the ignored .cache/ directory. macOS may ask for Bluetooth permission on the first BLE scan. If permission was denied, enable Bluetooth for the Python host app in **System Settings → Privacy & Security → Bluetooth**. A distributable app must have the Bluetooth usage-description key before making CoreBluetooth calls.

## Run

Take one snapshot:

~~~sh
python main.py --once
~~~

Watch continuously using the configured interval:

~~~sh
python main.py --watch
~~~

Request one nearby Wi-Fi scan, enable local speech, or skip Bluetooth:

~~~sh
python main.py --once --scan-wifi
python main.py --watch --speak
python main.py --watch --no-bluetooth
~~~

Use --json to print a machine-readable snapshot. Stop watch mode with Control-C.

## Configuration

Copy config.example.json to settings.json; local settings are ignored by Git. Edit:

- **monitor.interval_seconds:** seconds between snapshots in watch mode.
- **monitor.bluetooth_every_n_cycles:** scan BLE every N snapshots to reduce radio and battery use.
- **monitor.bluetooth_scan_seconds:** scan duration for each BLE snapshot.
- **monitor.read_gatt_battery:** optionally connect to known advertising devices and try the standard battery characteristic. This can trigger a device permission or pairing prompt; leave it off unless needed.
- **known_devices:** exact or partial advertised names such as Personal Phone or My AirPods.
- **thresholds:** battery, thermal, network-loss, and cooldown policy.
- **speech.enabled** and **speech.voice:** local macOS say output configuration.

Example device names are placeholders. Add only devices you own or are authorized to monitor. The tool keeps transient CoreBluetooth UUIDs in memory only and does not write device identifiers to disk.

## Persona and alert policy

The deterministic persona engine consumes structured observations and emits short lines only for observed events. It does not let a language model invent sensor facts. Threshold crossings use hysteresis and cooldowns to avoid chatter:

- Battery warning at or below 20% while on battery; clear above 25% or when connected to AC.
- Thermal warning at serious or critical; clear after recovery readings.
- Gateway instability after repeated loss snapshots; clear after repeated healthy snapshots.
- Known-device arrival/departure only after multiple BLE scans, described as a signal sighting rather than location.

Example original lines:

- “We’re at 18%, and the charger is conspicuously absent. I can dim the theatrics and save some power.”
- “Thermals are elevated. I’m pausing optional work so the Mac can shed some heat.”
- “The gateway missed checks. The local network path is having a day.”

## Troubleshooting

- **Swift bridge does not build:** Confirm swiftc is installed with Xcode Command Line Tools. Build diagnostics are printed without elevated privileges.
- **Wi-Fi signal or scan is missing:** The interface may be disconnected, unavailable, or access may be restricted. The script leaves unknown values unset instead of guessing.
- **No BLE devices appear:** Nearby devices must advertise BLE. Try a longer configured scan and confirm Bluetooth access. A paired-device list is not the same as an advertising scan.
- **macOS 12.0–12.2 BLE scan is empty:** Bleak documents a CoreBluetooth scan issue on these releases when no service filter is supplied. Upgrade to macOS 12.3 or later for unfiltered scans.
- **Accessory battery is absent:** macOS does not expose battery for every device. GATT battery reads work only for devices that implement the standard service and allow access.
- **Thermal state is unknown:** The Swift bridge could not query Foundation; this is not interpreted as a hot device.
- **Voice output is silent:** Confirm local speech is enabled and a voice is installed in macOS. No network voice service is used.

## Platform references

- [Apple CoreWLAN](https://developer.apple.com/documentation/CoreWLAN) for Wi-Fi interface readings and scans.
- [Apple CoreBluetooth](https://developer.apple.com/documentation/corebluetooth/cbcentralmanager) for BLE discovery.
- [Apple ProcessInfo thermal state](https://developer.apple.com/documentation/foundation/processinfo/thermalstate-swift.enum) for system thermal levels.
- [Bleak macOS backend and permissions](https://bleak.readthedocs.io/en/latest/backends/macos.html) for CoreBluetooth behavior and Bluetooth purpose strings.

## Repository layout

~~~text
cortana-macos-companion/
├── README.md
├── LICENSE
├── .gitignore
├── requirements.txt
├── config.example.json
├── main.py
├── hardware_bridge.py
├── persona_engine.py
└── native/
    └── mac_bridge.swift
~~~

## Roadmap

1. Build a SwiftUI menu-bar panel with the blue glass visual language, transcript, and restrained waveform.
2. Add opt-in on-device speech recognition with a clear microphone control.
3. Add local reminders and Spotlight search behind explicit confirmation for actions.
4. Add an optional local LLM adapter that receives structured facts and cannot alter or invent sensor values.
5. Package as a signed macOS app with permission descriptions and accessibility review.

## Attribution

Made with \[Chat Gpt Luna\]. Copyright notices in this repository preserve that attribution. The MIT License grants the standard rights to use, modify, and distribute the code.
